"use client"

import  from "../scripts/relatorios"

export default function SyntheticV0PageForDeployment() {
  return < />
}